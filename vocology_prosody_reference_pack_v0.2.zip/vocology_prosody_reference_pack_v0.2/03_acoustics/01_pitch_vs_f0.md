# Pitch vs F0

**F0** is physical periodicity. **Pitch** is perceptual. They correlate, but diverge when:
- the fundamental is weak/missing (missing fundamental illusion),
- strong harmonics dominate,
- noise is high,
- polyphonic/instrumental leakage exists,
- the signal is inharmonic.

For correction: do not trust raw F0 without confidence + continuity.

## Cents
`cents = 1200 * log2(f2 / f1)`
100 cents = 1 semitone (equal temperament)
