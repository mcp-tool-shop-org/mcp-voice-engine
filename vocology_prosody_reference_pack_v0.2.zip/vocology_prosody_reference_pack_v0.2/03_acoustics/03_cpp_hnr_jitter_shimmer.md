# CPP, HNR, Jitter, Shimmer (features with failure modes)

## HNR — Harmonic-to-Noise Ratio
Proxy for periodicity vs noise.
Good for voicing confidence and “No Warble” gating.
Failure: mic/room noise, fricatives, windowing can distort.

## CPP — Cepstral Peak Prominence
Measures prominence of periodicity peak in the cepstrum.
Useful periodicity indicator under mild noise.
Failure: sensitive to signal chain processing, short windows, extremes.

## Jitter/Shimmer
Cycle-to-cycle period / amplitude variation.
Failure: requires reliable cycle detection; brittle in breathy/creaky/noisy segments.

Engineering recommendation:
Use a robust multi-cue confidence measure; treat jitter/shimmer-like signals as auxiliary flags.
