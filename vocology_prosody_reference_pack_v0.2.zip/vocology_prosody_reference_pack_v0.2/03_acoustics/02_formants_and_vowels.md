# Formants & vowels

Formants (F1/F2/…) are vocal tract resonances shaping vowels.

Trends:
- higher tongue → lower F1
- more front tongue → higher F2
- lip rounding → lowers formants

Pitch shifting changes harmonic spacing; if you don’t preserve envelope/formants,
vowels can morph and identity shifts.

Common implementation families:
- LPC envelope extraction + resynthesis
- phase vocoder with envelope constraints (cepstral liftering)
- PSOLA variants + envelope handling
- WORLD-style decomposition (F0, envelope, aperiodicity)
