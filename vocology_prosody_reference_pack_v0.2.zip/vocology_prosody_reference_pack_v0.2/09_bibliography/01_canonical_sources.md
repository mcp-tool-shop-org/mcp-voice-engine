# Canonical sources (non-exhaustive)

Books / foundational:
- Johan Sundberg — *The Science of the Singing Voice*
- Ingo Titze — *Principles of Voice Production* (and related work)
- Acoustic phonetics texts (e.g., Ladefoged & others)
- Intonation/prosody literature (AM theory, ToBI systems)

Tools:
- Praat (analysis)
- parselmouth (Python interface to Praat)
- librosa, pyworld, WORLD vocoder ecosystem
- pYIN/YIN implementations

Concepts worth studying:
- ToBI (Tone and Break Indices)
- CPP/CPPS, HNR
- Glottal inverse filtering, LF model
- Vibrato rate/extent, portamento modeling
