# Search terms & topics (for deeper literature pulls)

Prosody:
- autosegmental-metrical (AM) theory
- ToBI, boundary tones, pitch accents
- declination, downstep, pitch reset
- post-focus compression

Voice source:
- LF model (Liljencrants–Fant)
- open quotient, speed quotient
- H1-H2, H1-A2 (tilt measures)
- glottal inverse filtering

Pitch tracking:
- YIN, pYIN, SWIPE, RAPT
- voicing decision, confidence measures

Formants:
- LPC formant tracking pitfalls
- nasalization antiresonances

Singing:
- note onset detection
- vibrato estimation (rate/extent)
- portamento segmentation
