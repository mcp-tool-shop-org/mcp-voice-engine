# What is prosody?

**Prosody** is the patterning of speech over time:
- **Intonation**: pitch movement (F0 contours)
- **Rhythm**: timing patterns, tempo, duration
- **Stress/Prominence**: what stands out (pitch + intensity + duration bundle)
- **Phrasing**: grouping with boundary cues (pauses, lengthening, pitch reset)

Prosody encodes meaning beyond words: emphasis, questions, turn-taking, attitude.

Engineering consequence: prosody control is *multi-parameter*; pitch alone is rarely enough.
