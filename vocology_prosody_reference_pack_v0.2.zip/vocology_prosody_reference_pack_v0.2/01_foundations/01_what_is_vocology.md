# What is vocology?

**Vocology** studies how voices are produced, trained, used, and sometimes rehabilitated.
For engineers it’s a map from **control variables** (breath pressure, vocal fold closure, tract shaping)
to **acoustic outputs** (F0, formants, tilt, noise) and **perceptual qualities** (brightness, effort, breathiness).

## Why DSP/ML people should care
Pitch correction and expressivity systems fail when they ignore:
- voicing confidence (unvoiced frames *must not* be tuned),
- consonants/noise handling,
- vibrato and glides,
- formants / spectral envelope.

Vocology gives you the failure modes to test for.

## Source–filter model (useful approximation)
1) **Source** (larynx): periodic pulses (voiced) or turbulence (unvoiced), plus intensity/tilt  
2) **Filter** (vocal tract): resonances (formants), antiresonances (nasal coupling)  
3) **Radiation + chain**: mouth radiation, room, mic, compression
