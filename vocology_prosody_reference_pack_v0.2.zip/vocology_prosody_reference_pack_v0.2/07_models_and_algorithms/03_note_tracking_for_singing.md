# Note tracking for singing (monophonic) — beyond raw F0

Singing includes vibrato, portamento, ornamentation, scoops/falls.
A note tracker infers intended *discrete targets* + transitions.

Deterministic sketch:
1) frame-wise F0 + confidence
2) convert to cents
3) smooth within voiced spans
4) segment into plateaus vs transitions (variance + slope)
5) quantize plateaus with hysteresis
6) during transitions, optionally reduce correction (preserve glide)

Metrics:
- note onset/offset timing error
- cent error on plateaus
- transition naturalness (avoid staircase)
