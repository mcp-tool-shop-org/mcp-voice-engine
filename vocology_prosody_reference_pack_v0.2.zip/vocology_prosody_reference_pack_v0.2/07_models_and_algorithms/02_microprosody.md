# Microprosody (consonant-induced perturbations)

Consonants can systematically perturb F0:
- voiceless consonants often disrupt/depress F0
- transitions can induce local bumps/dips

Why it matters:
Naive correction “fixes” these perturbations → unnatural motion and warble.

Strategies:
- confidence gate around unvoiced consonants
- emphasize correction on vowel nuclei
- decompose F0 into slow trend + fast residual
  - quantize/correct the trend
  - preserve residual (vibrato + microprosody)
