# F0 smoothing & hysteresis for musical stability

Autotune artifacts happen when correction follows micro-jitter.

Tools:
- median filter (kill spikes)
- EMA smoothing (control lag)
- asymmetric attack/release smoothing on *applied correction*
- hysteresis around quantization boundaries (prevents chatter)

Boundary chatter:
When pitch hovers near a semitone boundary, naive snapping oscillates between notes.
Hysteresis: commit to a note until you cross a threshold beyond the boundary.
