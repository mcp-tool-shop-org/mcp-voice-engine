# Prominence, focus, information structure

Focus (contrast/emphasis) often expressed by:
- local pitch accent
- duration + intensity increase
- post-focus compression (reduced pitch range after focus)

Detection sketch:
Prominence score ≈ z(intensity) + z(duration proxy) + z(|F0 slope|)

TTS control implication:
Better than one “emphasis” knob:
- emphasis strength
- accent type (rise/fall)
- timing within word
- post-focus compression strength
