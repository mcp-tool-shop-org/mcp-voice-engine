# Rhythm, timing, prominence

Prominence bundle:
- increased duration
- increased intensity
- pitch movement or local peak
- sometimes spectral tilt shift (effort/brightness)

Boundary cues:
- pre-boundary lengthening
- pause
- pitch reset or boundary tones

Engineering metrics:
- pause distribution
- syllable-nucleus energy peaks vs timing
- F0 peak alignment with nuclei
