# Phrase boundaries: cues and detection

Cues:
- pauses (or micro-pauses)
- pre-boundary lengthening
- pitch reset
- intensity pattern changes

Why it matters:
- smoothing across boundaries smears meaning and causes artifacts
- phrase segmentation is a natural place to reset filters and tuning plans

Detection ideas:
- energy + silence detection with hysteresis
- local speaking-rate change
- F0 declination reset events
