# Intonation contours (speech melody)

Simplified English-ish patterns:
- declarative: gradual declination + final fall
- yes/no question: final rise
- continuation: phrase-final rise/level, not fully falling

Model F0 as layered structure:
1) micro-prosody (consonant perturbations)
2) accent targets (local rises/falls)
3) phrase baseline (declination + boundary resets)

For synthesis/control: separating layers yields more natural behavior than a single curve.
