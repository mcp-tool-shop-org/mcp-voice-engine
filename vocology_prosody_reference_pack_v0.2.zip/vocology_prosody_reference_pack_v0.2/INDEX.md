# Index

Start with:
- `01_foundations/01_what_is_vocology.md`
- `01_foundations/02_what_is_prosody.md`

Then the “make it not embarrassing” core:
- `06_measurement/02_voicing_and_confidence.md`
- `07_models_and_algorithms/01_f0_smoothing_and_hysteresis.md`
- `08_applications/01_autotune_humanization.md`

Deep modules:
- `07_models_and_algorithms/02_microprosody.md`
- `07_models_and_algorithms/03_note_tracking_for_singing.md`
- `08_applications/02_formant_preservation_strategies.md`
