# Formant preservation strategies (overview)

Goal: pitch-shift source periodicity while keeping spectral envelope (formants) stable.

Families:
A) PSOLA-like: natural for small shifts; needs good period detection; struggles with noise/large shifts
B) Phase vocoder + envelope constraints: flexible; can be “phasier” if not tuned
C) LPC envelope remove/restore: explicit control; brittle under noise/high pitch
D) WORLD-style decomposition: strong separation; may introduce vocoder character

Rule:
Decide target use-case first: speech micro-correction vs singing wide ranges vs deliberate voice transformation.
