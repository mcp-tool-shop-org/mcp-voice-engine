# Autotune humanization (deterministic edition)

Human pitch is not a straight line. Humanization aims to:
- preserve vibrato
- avoid instant snapping
- avoid robotic cent perfection
- keep boundaries stable (no chatter)

Deterministic humanization:
- any randomness must be seeded
- derive micro-variation from stable indices or explicit seed

Levers:
- strength (blend)
- attack/release smoothing on applied correction
- hysteresis
- confidence gate (No Warble)
- vibrato preservation: correct the *center*, not the oscillation
