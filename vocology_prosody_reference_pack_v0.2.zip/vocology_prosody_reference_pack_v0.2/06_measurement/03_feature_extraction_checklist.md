# Feature extraction checklist (DSP pipelines)

Preprocessing:
- DC removal
- optional gentle HPF (50–80 Hz) to reduce rumble
- avoid nonlinear limiting if you care about CPP/HNR stability

Windows:
- 20–50 ms frames, 5–10 ms hop (typical)
- treat voiced/unvoiced segments differently

Core features:
- F0 + confidence
- RMS/energy envelope
- harmonicity proxy (HNR-ish)
- spectral centroid/rolloff (brightness proxies)
- tilt proxy

Pitfalls:
- features are not “truth”
- maintain synthetic-signal unit tests: pure tone, harmonic stack, vibrato FM, noise bursts, missing fundamental
