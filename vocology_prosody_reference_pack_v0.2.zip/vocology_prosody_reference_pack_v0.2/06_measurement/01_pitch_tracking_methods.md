# Pitch tracking methods (and their betrayals)

- Autocorrelation: simple, octave errors possible
- YIN / pYIN: strong baselines with continuity advantages
- Cepstrum: robust periodicity cue; can confuse with formants
- HPS: reinforces fundamentals but can be brittle

Practical advice:
- always compute confidence
- enforce continuity (don’t tune frame-by-frame independently)
- treat creaky/breathy/noisy segments as “special”
