# Voicing detection & confidence gating (“No Warble”)

Rule:
> If confidence is low, do not correct (or smoothly decay correction to 0).

Support for voicing:
- strong periodicity peak (YIN CMND, autocorr peak, CPP proxy)
- harmonic structure / harmonicity
- stable inter-frame pitch
- sufficient energy

Reduce confidence for:
- broadband noise bursts (fricatives, breath)
- low energy
- irregular pulses (creak)
- multiple competing pitch candidates

Engineering pattern:
- compute f0 + confidence
- `is_voiced = confidence >= minConfidence`
- if unvoiced: shift = 0 (or decay)
- else: apply controlled correction
