# Spectral tilt and perceived effort

Spectral tilt: how quickly harmonic magnitudes fall with frequency.

- Abrupt closure → more high-frequency energy → flatter tilt → “brighter/edgier”
- Breathy phonation → steeper tilt + more noise

Measures (approximate):
- H1-H2
- H1-A2
- harmonic slope across bands

Caution: formants complicate tilt measurement; validate with controlled signals.
