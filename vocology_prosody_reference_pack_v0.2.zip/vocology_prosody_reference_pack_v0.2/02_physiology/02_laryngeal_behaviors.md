# Laryngeal behaviors & voice qualities (non-clinical)

## Breathy
Incomplete closure; more turbulent airflow.
Acoustics: higher noise floor, steeper spectral tilt, lower harmonicity (HNR).

## Pressed / strained
Strong closure; more high-frequency harmonics, flatter tilt; can push nonlinearities.
Perception: “edge”, effort.

## Creaky / fry
Irregular low-frequency pulses; subharmonics; unstable period.
Pitch trackers often fail here → confidence gating matters.

## Falsetto
Different vibratory mode; fewer strong harmonics; often breathier.

Engineering note: a pitch tracker without confidence is a warble generator.
