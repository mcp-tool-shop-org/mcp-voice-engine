# Source–filter model (engineering summary)

Speech ≈ Source (glottal excitation) passed through Filter (vocal tract resonances).

Practical implications:
- Pitch shifting changes harmonic spacing (source).
- Vowels are largely defined by formants (filter).
- Shift F0 without envelope/formant handling → “chipmunk/giant” vowels.

Source controls (simplified):
- subglottal pressure → loudness/energy
- adduction/closure → breathy ↔ pressed continuum
- pulse shape → spectral tilt (abrupt closure => more high harmonics)

Filter controls:
- tongue height/frontness → F1/F2
- lip rounding → lowers formants
- nasal coupling → antiresonances + spectral shaping
