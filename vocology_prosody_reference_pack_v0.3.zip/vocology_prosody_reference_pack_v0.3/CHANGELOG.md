# Changelog

## v0.3 — 2026-02-14
Added expanded notes.
