# Canonical sources (non-exhaustive)

Books / foundational:
- Johan Sundberg — *The Science of the Singing Voice*
- Ingo Titze — *Principles of Voice Production*
- Acoustic phonetics texts (e.g., Ladefoged and others)
- Prosody/intonation literature (AM theory, ToBI)

Tools:
- Praat
- parselmouth (Praat in Python)
- librosa, pyworld, WORLD vocoder ecosystem
- YIN / pYIN implementations
