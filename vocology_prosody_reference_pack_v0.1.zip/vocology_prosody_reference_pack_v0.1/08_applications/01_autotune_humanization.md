# Autotune humanization (deterministic edition)

Humanization usually means:
- preserve vibrato
- avoid instant snapping
- avoid robotic perfect cent accuracy
- keep transitions smooth at note boundaries

Deterministic humanization:
- any randomness must be seeded
- better: correct the *center* trajectory and preserve higher-rate modulation (vibrato).
