# Source–filter model (engineering summary)

Speech production is often approximated as:

- **Source**: glottal airflow pulses (voiced) or turbulence noise (unvoiced)
- **Filter**: vocal tract resonances shaping the spectrum (formants)
- **Radiation**: mouth radiation and recording chain

Practical implications:
- Pitch shifting changes source periodicity; formants are filter resonances.
- If you shift F0 without handling formants, vowels can sound like a different person.
