# Laryngeal behaviors & voice qualities (non-clinical)

## Breathy
Incomplete closure → more turbulent airflow.
Acoustics: higher noise floor, steeper spectral tilt, lower HNR.

## Pressed / strained
Strong closure → stronger high harmonics, flatter tilt; can introduce nonlinearities.

## Creaky / vocal fry
Irregular low-frequency pulses → subharmonics, unstable period. Pitch trackers often struggle.

Engineering note: confidence gating is essential; otherwise you “tune the noise”.
