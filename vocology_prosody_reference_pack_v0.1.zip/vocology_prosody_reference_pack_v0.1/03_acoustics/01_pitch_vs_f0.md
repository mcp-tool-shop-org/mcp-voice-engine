# Pitch vs F0

**F0** is a physical measure: the fundamental frequency of periodic excitation.
**Pitch** is perceptual: what listeners hear as “high/low”.

They correlate but can diverge when:
- the fundamental is weak/missing,
- strong harmonics dominate,
- noise is high.

Cents: `c = 1200 * log2(f2 / f1)`
