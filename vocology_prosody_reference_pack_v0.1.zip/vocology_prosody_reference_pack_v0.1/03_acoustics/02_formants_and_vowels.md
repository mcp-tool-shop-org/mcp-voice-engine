# Formants & vowels (engineer edition)

Formants are resonant peaks (F1, F2, ...) of the vocal tract. They define vowel identity.

Why they matter:
- Pitch shifting changes harmonic spacing.
- If you shift harmonics without preserving envelope, vowels can morph (“chipmunk/giant”).

Implementation families:
- LPC envelope extraction + resynthesis
- Phase vocoder with envelope constraints / cepstral liftering
- PSOLA variants with envelope handling
