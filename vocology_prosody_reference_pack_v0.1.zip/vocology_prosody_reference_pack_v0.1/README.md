# Vocology & Prosody Reference Pack (v0.1)

Engineering-oriented reference notes on vocology (voice science/practice) and prosody (rhythm, stress, intonation).

Built: 2026-02-14T02:39:24.733992Z

## Structure

- `01_foundations/` — key concepts, definitions, mental models
- `02_physiology/` — vocal system anatomy/physiology for engineers
- `03_acoustics/` — acoustic correlates and measurable features
- `04_prosody/` — timing, intonation, stress, phrasing, prominence
- `05_voice_quality/` — breathy/creaky/pressed, resonance, formants, spectral tilt
- `06_measurement/` — practical measurement methods, pitfalls, recommended metrics
- `07_models_and_algorithms/` — pitch tracking, voicing, smoothing, hysteresis
- `08_applications/` — TTS, singing, autotune/humanization, expressive control
- `09_bibliography/` — canonical books, papers, tools worth knowing

Start with `INDEX.md`.
