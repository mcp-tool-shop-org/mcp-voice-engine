# Spectral tilt and perceived effort

**Spectral tilt** describes how quickly harmonic amplitudes fall off with frequency.

- Abrupt closure → more high-frequency energy → flatter tilt (“brighter/edgier”)
- Breathy phonation → steeper tilt + more noise

Common measures (approximate): H1-H2, H1-A2, harmonic slope across bands.
