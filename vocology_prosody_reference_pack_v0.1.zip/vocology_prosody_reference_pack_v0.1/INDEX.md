# Index

- Foundations:
  - `01_foundations/01_what_is_vocology.md`
  - `01_foundations/02_what_is_prosody.md`

- Key engineering principles:
  - `06_measurement/02_voicing_and_confidence.md`
  - `07_models_and_algorithms/01_f0_smoothing_and_hysteresis.md`

- Autotune & humanization:
  - `08_applications/01_autotune_humanization.md`

- Bibliography:
  - `09_bibliography/01_canonical_sources.md`
