# F0 smoothing & hysteresis for musical stability

Even good pitch detection jitters. Avoid reacting to micro-perturbations.

Tools:
- median filter on cents-domain F0 (spike removal)
- EMA smoothing (control lag)
- asymmetric attack/release smoothing on applied shift
- hysteresis around quantization boundaries to prevent chatter

Rule of thumb: 10–25 cents hysteresis is often enough; tune via stress tests.
