# Voicing detection & confidence gating (“No Warble”)

A robust autotune pipeline needs a gate that says:
> “This frame is sufficiently voiced and pitch-stable to correct.”

Support voicing:
- high harmonicity / periodicity peak strength
- stable inter-frame pitch
- sufficient energy

Reduce confidence:
- fricatives/breath (broadband noise)
- very low energy
- irregular period (creak)
- multiple pitch candidates

Pattern:
- compute `f0`, `confidence`
- if confidence < threshold → shift=0 (or smoothly decay)
- else → apply correction
