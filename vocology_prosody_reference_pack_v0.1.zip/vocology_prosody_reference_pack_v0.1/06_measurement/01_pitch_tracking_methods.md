# Pitch tracking methods (and why they betray you)

- Autocorrelation: can octave-error; needs voicing decision.
- YIN / pYIN: strong baselines; pYIN adds temporal smoothing.
- Cepstrum: periodicity cue; can be confused by formants.
- HPS: reinforces fundamentals; brittle in noise.

Advice:
- Always compute **voicing confidence**.
- Prefer **continuity constraints** over per-frame “best guess”.
