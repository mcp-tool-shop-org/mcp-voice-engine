# What is prosody?

**Prosody** is the patterning of speech (and singing-like speech) over time:

- **Intonation**: pitch movement and contours (F0 trajectories)
- **Rhythm**: timing patterns, syllable durations, tempo
- **Stress/Prominence**: which syllables/words stand out (often via pitch + loudness + duration)
- **Phrasing**: grouping into units with boundary cues (pauses, lengthening, pitch resets)

Engineering consequence: prosody control is best done with **multiple coordinated parameters**, not pitch alone.
