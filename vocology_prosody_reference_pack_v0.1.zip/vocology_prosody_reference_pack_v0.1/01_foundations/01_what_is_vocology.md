# What is vocology?

**Vocology** is the study and practice of voice habilitation: how voices are produced, trained, used, and sometimes
repaired (clinically or pedagogically). It spans physiology, acoustics, perception, pedagogy, and clinical practice.

For engineers: vocology is a map from **control variables** (subglottal pressure, vocal fold adduction, tract shaping)
to **acoustic outputs** (F0, formants, spectral tilt, noise) and **perceptual qualities** (brightness, effort, breathiness).

## Source–filter model (useful approximation)

1) **Source** (larynx): periodic excitation (voiced) vs aperiodic noise (unvoiced), plus intensity/tilt  
2) **Filter** (vocal tract): resonances (formants), anti-resonances (nasal coupling)  
3) **Radiation + chain**: mouth radiation, room, mic, compression

Pitch shifting mostly alters the *source*; vowel identity is largely in the *filter*.
